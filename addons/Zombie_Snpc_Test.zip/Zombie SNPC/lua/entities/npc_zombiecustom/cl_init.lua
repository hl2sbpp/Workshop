--======== Copyright (C) 2025-2025, Team HL2SB++, All rights reserved. ========--
--
-- Purpose:
--
--===========================================================================--

includeC("shared.lua")

function ENT:DrawModel(flags) end

function ENT:ClientThink() end
