--======== Copyright (C) 2025-2025, Team HL2SB++, All rights reserved. ========--
--
-- Purpose:
--
--===========================================================================--
-- tf are you searching for?? :james_doakes:

includeC("shared.lua")

local ATTACK_RADIUS = 100
local MAX_TARGETS = 3
local ATTACK_INTERVAL = 0.5
local MOVE_SPEED = 400
local TRIGGER_RADIUS = 700

local function AngleDifference(a, b)
  local diff = (a - b) % 360
  if diff > 180 then
    diff = diff - 360
  end
  return diff
end

function ENT:DeathThink()
  local pos = self:GetAbsOrigin()
  local ang = self:GetAbsAngles()
  local model = self:GetModelName()

  -- spawn ragdoll
  local ragdoll = CreateEntityByName("prop_ragdoll")
  if ragdoll ~= nil then
    ragdoll:SetModel(model)
    ragdoll:SetAbsOrigin(pos)
    ragdoll:SetAbsAngles(ang)

    ragdoll:Spawn()
    ragdoll:Activate()
  end

  self:Remove()
end

function ENT:IsObstacleAhead()
  local eyePos = self:GetAbsOrigin() + Vector(0, 0, 40)

  local ang = self:GetAbsAngles()
  local forward = Vector(math.cos(math.rad(ang.y)), math.sin(math.rad(ang.y)), 0)

  local tr = trace_t()
  local maskShot = _E.MASK.SHOT

  UTIL.TraceLine(eyePos, eyePos + forward * 60, maskShot, self, 0, tr)

  return tr.Hit
end

function ENT:IsOnGround()
  local startPos = self:GetAbsOrigin()
  local tr = trace_t()
  UTIL.TraceLine(startPos, startPos - Vector(0, 0, 5), _E.MASK.SOLID, self, 0, tr)
  return tr.Hit
end

function ENT:Jump()
  local phys = self:VPhysicsGetObject()
  if phys ~= NULL and self:IsOnGround() then
    phys:ApplyForceCenter(Vector(0, 0, 1) * 4000)
  end
end

function ENT:DoFootstep()
  local seq = self:GetSequenceName(self:GetSequence())

   if seq == "Full_sprint" then
    return
  end

  -- i hate this
  if self.FootstepLeft then
    self:EmitSound("tnaf/sprintstep1.wav")
  else
    self:EmitSound("tnaf/sprintstep2.wav")
  end

  self.FootstepLeft = not self.FootstepLeft
end

function ENT:HandleFootsteps()
  local curtime = gpGlobals.curtime()

  local phys = self:VPhysicsGetObject()
  local velocity = self:GetAbsVelocity():Length()
  if phys and phys ~= NULL then
    velocity = phys:GetVelocity():Length()
  end

  local speed = velocity or 0
  local walkingThreshold = 20

  if speed > walkingThreshold and self:IsOnGround() then
    local interval = math.clamp(self.FootstepIntervalBase * (130 / math.max(speed, 1)), 0.18, 0.6)
    if curtime >= (self.NextFootstepTime or 0) then
      self:DoFootstep()
      self.NextFootstepTime = curtime + interval
    end
  else
    self.NextFootstepTime = curtime
  end
end

local function GetNearestPlayers(pos, radius)
  local players = player.GetAll()
  local candidates = {}

  for _, ply in ipairs(players) do
    if IsValid(ply) and ply:IsAlive() then
      local d = (ply:GetAbsOrigin() - pos):Length()
      if d <= radius then
        table.insert(candidates, { ply = ply, dist = d })
      end
    end
  end

  table.sort(candidates, function(a, b)
    return a.dist < b.dist
  end)
  return candidates
end

function ENT:AttackNearestPlayers()
  local now = gpGlobals.curtime()
  if self._NextAttackTime and now < self._NextAttackTime then
    return
  end
  self._NextAttackTime = now + ATTACK_INTERVAL

  local pos = self:GetAbsOrigin()
  local candidates = GetNearestPlayers(pos, ATTACK_RADIUS)
  if #candidates == 0 then
    return
  end

  local toAttack = math.min(MAX_TARGETS, #candidates)
  for i = 1, toAttack do
    local target = candidates[i].ply
    if IsValid(target) and target:IsAlive() then
      effect.Dissolve(target, "sprites/blueglow1.vmt", gpGlobals.curtime(), 0)
      self:EmitSound("096/hit.mp3")
    end
  end
end

function ENT:MoveThink()
  local pos = self:GetAbsOrigin()

  if not self.TargetPos or (pos - self.TargetPos):Length() < 40 and self.DoMove then
    local currentPos = self:GetAbsOrigin()
    local nearestArea = navmesh.GetNearestNavArea(currentPos)

    local newTarget = nil
    if nearestArea then
      local adjacentCount = nearestArea:GetAdjacentCount(0)
      if adjacentCount > 0 then
        local randomIndex = random.RandomInt(0, adjacentCount - 1)
        local nextArea = nearestArea:GetAdjacentArea(0, randomIndex)
        if nextArea then
          newTarget = nextArea:GetRandomPoint()
        end
      end

      if not newTarget then
        newTarget = nearestArea:GetRandomPoint()
      end
    else
      --Warning("Unable to find nearest area. Do you have a navigation mesh?\n")
      newTarget = pos + Vector(random.RandomInt(-2000, 2000), random.RandomInt(-2000, 2000), 0)
    end

    if newTarget then
      self.TargetPos = newTarget
    end
  end

  -- quite a hacky hack
  if self.FollowPlayer and self.DoMove then
    local nearestPlayer, dist = self:GetNearestPlayer()
    if nearestPlayer then
      self.TargetPos = nearestPlayer:GetAbsOrigin()

      local headPos = self:GetBonePosition(self:LookupBone("ValveBiped.Bip01_Head1"), Vector(0, 0, 0), QAngle(0, 0, 0))
        or self:GetAbsOrigin()
      local delta = nearestPlayer:GetAbsOrigin() + Vector(0, 0, 40) - headPos -- look at player head
      local targetYaw = math.deg(math.atan2(delta.y, delta.x))
      local targetPitch = math.deg(math.atan2(-delta.z, math.sqrt(delta.x ^ 2 + delta.y ^ 2)))

      local yawIndex = self:LookupPoseParameter("eyes_leftright")
      local pitchIndex = self:LookupPoseParameter("eyes_updown")

      if yawIndex >= 0 then
        local currentYaw = self:GetPoseParameter(yawIndex)
        local desiredYaw = math.clamp(targetYaw / 90, -1, 1)
        local smoothYaw = currentYaw + (desiredYaw - currentYaw) * 0.1
        self:SetPoseParameter(yawIndex, smoothYaw)
      end

      if pitchIndex >= 0 then
        local currentPitch = self:GetPoseParameter(pitchIndex)
        local desiredPitch = math.clamp(targetPitch / 90, -1, 1)
        local smoothPitch = currentPitch + (desiredPitch - currentPitch) * 0.1
        self:SetPoseParameter(pitchIndex, smoothPitch)
      end
    end
  end

  if self.TargetPos and self.DoMove then
    local dir = self.TargetPos - pos
    local len = dir:Length()
    if len > 0 then
      dir = dir / len

      local trGround = trace_t()
      local groundTraceDist = 32
      UTIL.TraceLine(pos, pos - Vector(0, 0, groundTraceDist), _E.MASK.SOLID, self, 0, trGround)

      local groundNormal = Vector(0, 0, 1)
      local onGround = false
      if trGround and trGround.Hit then
        onGround = true
        if trGround.PlaneNormal then
          groundNormal = trGround.PlaneNormal
        end
      end

      -- forward = dir - (groundNormal * dot(dir, groundNormal))
      local dot = dir.x * groundNormal.x + dir.y * groundNormal.y + dir.z * groundNormal.z
      local forward = Vector(dir.x - groundNormal.x * dot, dir.y - groundNormal.y * dot, dir.z - groundNormal.z * dot)

      if forward:Length() <= 0.001 then
        forward = Vector(dir.x, dir.y, 200)
        if forward:Length() > 0 then
          forward = forward:GetNormalized()
        end
      else
        forward = forward:GetNormalized()
      end

      local desiredVel = forward * MOVE_SPEED

      local phys = self:VPhysicsGetObject()
      if phys and phys ~= NULL then
        local curVel = phys:GetVelocity()
        local preservedZ = curVel.z or 0

        phys:SetVelocity(Vector(desiredVel.x, desiredVel.y, preservedZ), Vector(desiredVel.x, desiredVel.y, preservedZ))
        self:SetAbsVelocity(Vector(desiredVel.x, desiredVel.y, preservedZ))
      else
        local curAbs = self:GetAbsVelocity() or Vector(0, 0, 0)
        local preservedZ = curAbs.z or 0
        self:SetAbsVelocity(Vector(desiredVel.x, desiredVel.y, preservedZ))
      end

      local desiredYaw = math.deg(math.atan2(forward.y, forward.x))
      local curAng = self:GetAbsAngles()
      local smoothYaw = curAng.y + AngleDifference(desiredYaw, curAng.y) * 0.1
      curAng.y = smoothYaw
      self:SetAbsAngles(curAng)
    end
  end

  if self:IsObstacleAhead() and self:IsOnGround() then
    local phys = self:VPhysicsGetObject()
    if phys and phys ~= NULL then
      phys:ApplyForceCenter(Vector(0, 0, 1) * 2000)
    else
      local cur = self:GetAbsVelocity()
      self:SetAbsVelocity(Vector(cur.x, cur.y, math.max(cur.z, 100)))
    end
  end
end

function ENT:LookAtTarget(targetPos)
  local headPos = self:GetBonePosition(self:LookupBone("ValveBiped.Bip01_Head1"), Vector(0, 0, 0), QAngle(0, 0, 0))
    or self:GetAbsOrigin()
  local delta = targetPos - headPos

  local yaw = math.deg(math.atan2(delta.y, delta.x))
  local pitch = math.deg(math.atan2(-delta.z, math.sqrt(delta.x ^ 2 + delta.y ^ 2)))
  local ang = QAngle(pitch, yaw, 0)

  local yawIndex = self:LookupPoseParameter("eyes_leftright")
  local pitchIndex = self:LookupPoseParameter("eyes_updown")

  if yawIndex >= 0 then
    local yawVal = math.clamp(ang.y / 90, -1, 1)
    self:SetPoseParameter(yawIndex, yawVal)
  end
  if pitchIndex >= 0 then
    local pitchVal = math.clamp(ang.x / 90, -1, 1)
    self:SetPoseParameter(pitchIndex, pitchVal)
  end
end

function ENT:UpdateAnimation()
    local curtime = gpGlobals.curtime()
    local pos = self:GetAbsOrigin()

    local dt = curtime - (self._LastAnimPosTime or curtime)
    if dt <= 0 then
        dt = 0.001
    end
    local lastPos = self._LastAnimPos or pos
    local moved = pos - lastPos
    local displacementSpeed = moved:Length() / dt

    local physSpeed = 0
    local phys = self:VPhysicsGetObject()
    if phys and phys ~= NULL and phys.GetVelocity then
        physSpeed = phys:GetVelocity():Length()
    end
    local absSpeed = self:GetAbsVelocity() and self:GetAbsVelocity():Length() or 0

    local speed = displacementSpeed

    if self.DebugAnim and (curtime - (self._LastDebugPrintTime or 0) > 0.25) then
        print(string.format("AnimVel: disp=%.2f phys=%.2f abs=%.2f", displacementSpeed, physSpeed, absSpeed))
        self._LastDebugPrintTime = curtime
    end

    local movingThreshold = 2.0
    local weaponName = (self.Weapon and self.Weapon.GetName) and self.Weapon:GetName() or "None"

    local activity
    if self._IsChasing then
        activity = ACT.RUN
    elseif self.IsAngry then
        if self.AngryStage == 1 then
            activity = ACT.IDLE_AGITATED
        elseif self.AngryStage == 2 then
            activity = ACT.IDLE_AGITATED
        elseif self.AngryStage == 3 then
            activity = ACT.IDLE_ANGRY
        end
    else
        activity = ACT.CROUCHIDLE
    end

    local seq = self:SelectWeightedSequence(activity)
    if seq >= 0 then
        if self:GetSequence() ~= seq then
            self:SetPlaybackRate(2.2)
            self:ResetSequence(seq)
        end
        self:StudioFrameAdvance()
        self.LastAnimTime = curtime
    end

    self._LastAnimPos = pos
    self._LastAnimPosTime = curtime
end

function ENT:GetNearestPlayer()
  local nearest = nil
  local nearestDist = math.huge
  local myPos = self:GetAbsOrigin()

  for _, ply in ipairs(player.GetAll()) do
    if IsValid(ply) and ply:IsAlive() then
      local dist = (ply:GetAbsOrigin() - myPos):Length()
      if dist < nearestDist then
        nearestDist = dist
        nearest = ply
      end
    end
  end

  return nearest, nearestDist
end

function ENT:Think()
    local pos = self:GetAbsOrigin()
    local curTime = gpGlobals.curtime()
    self._LastMovePos = self._LastMovePos or pos
    self._LastMoveTime = self._LastMoveTime or curTime
    local distanceMoved = (pos - self._LastMovePos):Length()

    self.IsAngry = self.IsAngry or false
    self.AngryStage = self.AngryStage or 0 -- 0 = not angry, 1-3 = angry stages
    self.AngryDurations = self.AngryDurations or {2, 3, 4}
    self.AngryCooldown = self.AngryCooldown or 2
    self.AngryEndTime = self.AngryEndTime or 0
    self._AngrySoundPlayed = self._AngrySoundPlayed or false

    local nearestPlayer, dist = self:GetNearestPlayer()

    -- i farted
    if nearestPlayer and (dist <= TRIGGER_RADIUS or self._IsChasing) then
        self.MoveSpeed = 0

        if not self._ChaseSoundPlayed then
            self._ChaseSoundPlayed = true
        end

        if self.isEnemy and self.Weapon ~= NULL and self.Weapon then
            local shootPos = self:GetBonePosition(
                self:LookupBone("ValveBiped.Bip01_Head1"),
                Vector(0, 0, 0),
                QAngle(0, 0, 0)
            ) or pos + Vector(0, 0, 60)

            self:LookAtTarget(nearestPlayer:GetAbsOrigin())
            self.Weapon:SetOwnerEntity(self)
            self.IsFiring = true
            self.Weapon:PrimaryAttack()
            self.IsFiring = false
        end
    else
        self.MoveSpeed = 0
        self._IsChasing = false
        self._ChaseSoundPlayed = false
        self.IsAngry = false
        self.AngryStage = 0

        if not self._NextIdleSound or curTime >= self._NextIdleSound then
            self:EmitSound("096/idle.mp3")
            self._NextIdleSound = curTime + 8.0
        end
    end

    if nearestPlayer and dist <= TRIGGER_RADIUS then
        if self.AngryStage == 0 and curTime >= self.AngryEndTime then
            self.IsAngry = true
            self.AngryStage = 1
            self.AngryEndTime = curTime + self.AngryDurations[1]
            self._AngrySoundPlayed = false
        end

        if self.IsAngry then
            self.MoveSpeed = 0

            if not self._AngrySoundPlayed then
                self._AngrySoundPlayed = true
            end

            if curTime >= self.AngryEndTime then
                if self.AngryStage < 3 then
                    self.AngryStage = self.AngryStage + 1
                    self.AngryEndTime = curTime + self.AngryDurations[self.AngryStage]
                    self._AngrySoundPlayed = false
                else
                    self.IsAngry = false
                    self._IsChasing = true
                    self:EmitSound("096/chase.wav")
                    self.MoveSpeed = 600
                end
            end
        end
    end

    if self._IsChasing then
        self.MoveSpeed = 600
        self:MoveThink()
        self:AttackNearestPlayers()

        if self.isEnemy and self.Weapon ~= NULL and self.Weapon then
            self:LookAtTarget(nearestPlayer:GetAbsOrigin())
            self.Weapon:SetOwnerEntity(self)
            self.IsFiring = true
            self.Weapon:PrimaryAttack()
            self.IsFiring = false
        end
    else
        self.MoveSpeed = 0
    end

    self:UpdateAnimation()

    -- feet. wise words by markiplier
    if distanceMoved > 1 then
        if self.MoveSpeed > 300 then
            if not self._FootstepTime or curTime >= self._FootstepTime then
                self._FootstepTime = curTime + 0.2
            end
        else
            if not self._FootstepTime or curTime >= self._FootstepTime then
                self._FootstepTime = curTime + 0.25
            end
        end
    end

    -- so npc can get over curbs and shi
    if distanceMoved < 5 and curTime - self._LastMoveTime > 1.0 then
        local phys = self:VPhysicsGetObject()
        if phys and phys ~= NULL then
            phys:ApplyForceCenter(Vector(0, 0, 200))
        else
            local curVel = self:GetAbsVelocity()
            self:SetAbsVelocity(Vector(curVel.x, curVel.y, math.max(curVel.z, 10)))
        end
        self._LastMoveTime = curTime
        if self:IsObstacleAhead() then
            self:Jump()
        end
    end

    self._LastMovePos = pos
    self:SetNextThink(curTime)
    return true
end