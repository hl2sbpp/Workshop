-- @BartG1014: you will see this weapon in spawn menu without command 
-- MW2019

local mw2019Ak_sweps = {
    "weapon_mw19_ak47",
}

smlib.CreateHeader("Entities", "MW2019 AK")

for _, wep in ipairs(mw2019Ak_sweps) do
    local label = string.upper(wep) -- @BartG1014: THX!! @YourLocalMoon
    smlib.CreateButtonInHeader(
		true,
		"Entities",
		string.sub(label, 8),
		"materials/entities/" .. string.lower(wep) .. ".png", "",
		"give " .. wep .. ";use " .. wep,
		"MW2019 AK"
	)
end