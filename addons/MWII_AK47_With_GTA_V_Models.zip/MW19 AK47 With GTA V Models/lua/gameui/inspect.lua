-- .../gameui/inspect.lua

-- Credit @BartG1014

include( "../includes/extensions/panel.lua" )

local FCVAR_CLIENTDLL = _E.FCVAR.CLIENTDLL

require( "concommand" )

local function inspect() -- no more cfg :troll:
   engine.ClientCmd("alias +inspect global_set friendly_encounter 1; alias -inspect global_set friendly_encounter 0")
end

concommand.Create( "inspect", inspect, "inspect.", FCVAR_CLIENTDLL )