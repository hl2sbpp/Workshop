-- shared.lua

-- [SWEP] By @BartG1014

-- What are you looking for?

SWEP.PrintName				= "{MW19} Fist"
SWEP.ViewModel				= "models/weapons/v_fists.mdl"
SWEP.WorldModel				= ""
SWEP.AnimPrefix				= "python"
SWEP.Slot					= 5
SWEP.SlotPos				= 1

SWEP.Primary = 
{
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = true,
	Ammo = "None",
}

SWEP.Secondary = 
{
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = true,
	Ammo = "None",
}

SWEP.Weight					= 10
SWEP.ItemFlags				= 0

SWEP.Damage					= 25

SWEP.SoundData				=
{
	reload	=		"Default.Reload",
	single_shot = 	"weapons/fist/miss.wav",
	special1 = 		"weapons/fist/hit.wav",
	special2 = 		"weapons/fist/inspect.wav"
}

SWEP.ShowUsageHint			= false
SWEP.AutoSwitchTo			= true
SWEP.AutoSwitchFrom			= true
SWEP.BuiltRightHanded		= true
SWEP.AllowFlipping			= true
SWEP.MeleeWeapon			= true
SWEP.UseHands				= true

SWEP.DrawCrosshair = true
SWEP.DrawAmmo = false

SWEP.ViewModelFOV 			= 70

SWEP.DeploySpeed = 1.0

SWEP.m_acttable            =
{
	{ ACT.MP_STAND_IDLE,				ACT.HL2MP_IDLE_FIST,					false },
	{ ACT.MP_CROUCH_IDLE,				ACT.HL2MP_IDLE_CROUCH_FIST,			false },
	{ ACT.MP_RUN,						ACT.HL2MP_RUN_FIST,					false },
	{ ACT.MP_CROUCHWALK,				ACT.HL2MP_WALK_CROUCH_FIST,			false },
	{ ACT.MP_ATTACK_STAND_PRIMARYFIRE,	ACT.HL2MP_GESTURE_RANGE_ATTACK_FIST,	false },
	{ ACT.MP_ATTACK_CROUCH_PRIMARYFIRE,	ACT.HL2MP_GESTURE_RANGE_ATTACK_FIST,	false },
	{ ACT.MP_RELOAD_STAND,				ACT.HL2MP_GESTURE_RELOAD,		false },
	{ ACT.MP_RELOAD_CROUCH,				ACT.HL2MP_GESTURE_RELOAD,		false },
	{ ACT.MP_JUMP,						ACT.HL2MP_JUMP_FIST,					false },
	{ ACT.MP_SWIM,						ACT.HL2MP_SWIM_FIST,					false },
	{ ACT.MP_SWIM_IDLE,					ACT.HL2MP_SWIM_IDLE_FIST,					false },
};

function SWEP:Initialize()
	self.m_bReloadsSingly	= false;
	self.m_bFiresUnderwater	= true;
end

function SWEP:Precache()
end

function SWEP:PrimaryAttack()
    local pPlayer = self:GetOwner()
	if ( ToBaseEntity( pPlayer ) == NULL ) then
		return;
	end

	local vForward 		= Vector()
	local vRight 		= Vector()
	local vUp  			= Vector()
	local angle 		= QAngle()
	local vecEye 		= pPlayer:EyePosition();
	pPlayer:EyeVectors( vForward, vRight, vUp );

    local fRange = 70

    local startPos = pPlayer:Weapon_ShootPosition()
    local endPos = startPos + pPlayer:GetAutoaimVector( AUTOAIM_5DEGREES ) * fRange

	self:SendWeaponAnim( ACT.VM_PRIMARYATTACK );
	ToHL2MPPlayer(pPlayer):DoAnimationEvent( PlayerAnimEvent.ATTACK_PRIMARY );

	tr = trace_t()
	MASK_SHOT = _E.MASK.SHOT
    UTIL.TraceLine(startPos, endPos, MASK_SHOT, pPlayer, 0, tr)
	
    local bDidHit = tr:DidHit()
    local hitEnt = tr.m_pEnt

    self.m_flNextPrimaryAttack = gpGlobals.curtime() + 0.42
    self.m_flNextSecondaryAttack = self.m_flNextPrimaryAttack

	if bDidHit then
		if hitEnt then
			self:WeaponSound( WeaponSound.SPECIAL1 )
			self:SendWeaponAnim( ACT.VM_HITCENTER );
		end

		local vecSrc		= pPlayer:Weapon_ShootPosition();
		local vecAiming		= pPlayer:GetAutoaimVector( AUTOAIM_5DEGREES );

		local info = { m_iShots = 1, m_vecSrc = vecSrc, m_vecDirShooting = vecAiming, m_vecSpread = vec3_origin, m_flDistance = MAX_TRACE_LENGTH, m_iAmmoType = 1 };
		info.m_pAttacker = pPlayer;

		ToHL2MPPlayer( pPlayer ):FireBullets( info );

		local angles = pPlayer:GetLocalAngles();

		angles.x = angles.x + random.RandomInt( 0 );
		angles.y = angles.y + random.RandomInt( 0 );
		angles.z = 0;

if not _CLIENT then
		pPlayer:SnapEyeAngles( angles );
end
	else
		self:WeaponSound( WeaponSound.SINGLE )
	end

    pPlayer:ViewPunch(QAngle(0, math.random(0,0), 0))

    self.NextIdle = self.m_flNextPrimaryAttack - gpGlobals.curtime()
end

function SWEP:SecondaryAttack()
	self:SendWeaponAnim( ACT.VM_RELOAD ); -- don't ask me why
   self:WeaponSound( WeaponSound.SPECIAL2 )
end

function SWEP:Reload()
end

function SWEP:Think()
end -- @BartG1014: THINK MARK THINK!!

function SWEP:CanHolster()
end

function SWEP:Deploy()
    self.NextIdle = gpGlobals.curtime()
end

function SWEP:GetDrawActivity()
	return ACT.VM_IDLE;
end

function SWEP:Holster( pSwitchingTo )
end

function SWEP:ItemPostFrame()
end

function SWEP:ItemBusyFrame()
end

function SWEP:DoImpactEffect()
end --# SWEP By @BartG1014