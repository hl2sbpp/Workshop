-- shared.lua

-- [SWEP] By @BartG1014

-- What are you looking for?

SWEP.PrintName				= "{MW19} AK47"
SWEP.ViewModel				= "models/weapons/v_assaultrifle.mdl"
SWEP.WorldModel				= ""
SWEP.AnimPrefix				= "python"
SWEP.Slot					= 2
SWEP.SlotPos				= 1

SWEP.Primary = 
{
	ClipSize = 30,
	DefaultClip = 30,
	Automatic = true,
	Ammo = "AR2",
}

SWEP.Secondary = 
{
	ClipSize = -1,
	DefaultClip = -1,
	Automatic = false,
	Ammo = "none",
}

SWEP.DrawCrosshair 			= true
SWEP.DrawAmmo 				= true

SWEP.Weight					= 7
SWEP.ItemFlags				= 0

SWEP.Damage					= 16

SWEP.SoundData				=
{
	empty					= "Weapon_Pistol.Empty", -- sound empty
	single_shot				= "weapon_AK47.Single", -- sound fire
	special1 = 		"weapons/ads_in.wav", -- sound ads in
	special2 = 		"weapons/ads_out.wav", -- sound ads out
   single_shot_npc			= "weapons/fist/miss.wav", -- sound miss
	special3 = 		"weapons/fist/hit.wav" -- sound hit
}

SWEP.ShowUsageHint			= false
SWEP.AutoSwitchTo			= true
SWEP.AutoSwitchFrom			= true
SWEP.BuiltRightHanded		= true
SWEP.AllowFlipping			= true
SWEP.MeleeWeapon			= false
SWEP.UseHands				= true

SWEP.DrawCrosshair = true
SWEP.DrawAmmo = true

SWEP.ViewModelFOV 			= 70

SWEP.IronsightPosOffset = Vector(
	-2.721, 
	-2.7,
	0.698
)
SWEP.IronsightAngOffset = QAngle( 0.419, 0.067, -1.647 )
SWEP.IronsightFOVOffset = 4
SWEP.CanUseIronsight = true

SWEP.DeploySpeed = 1.0

SWEP.m_acttable            =
{
	{ ACT.MP_STAND_IDLE,				ACT.HL2MP_IDLE,					false },
	{ ACT.MP_CROUCH_IDLE,				ACT.HL2MP_IDLE_CROUCH,			false },
	{ ACT.MP_RUN,						ACT.HL2MP_RUN,					false },
	{ ACT.MP_CROUCHWALK,				ACT.HL2MP_WALK_CROUCH,			false },
	{ ACT.MP_ATTACK_STAND_PRIMARYFIRE,	ACT.HL2MP_GESTURE_RANGE_ATTACK,	false },
	{ ACT.MP_ATTACK_CROUCH_PRIMARYFIRE,	ACT.HL2MP_GESTURE_RANGE_ATTACK,	false },
	{ ACT.MP_RELOAD_STAND,				ACT.HL2MP_GESTURE_RELOAD,		false },
	{ ACT.MP_RELOAD_CROUCH,				ACT.HL2MP_GESTURE_RELOAD,		false },
	{ ACT.MP_JUMP,						ACT.HL2MP_JUMP,					false },
	{ ACT.MP_SWIM,						ACT.HL2MP_SWIM,					false },
	{ ACT.MP_SWIM_IDLE,					ACT.HL2MP_SWIM_IDLE,					false },
};

function SWEP:Initialize()
	self.m_bReloadsSingly	= false;
	self.m_bFiresUnderwater	= false;
	self.ADS = false;
end

function SWEP:Precache()
end

function SWEP:Melee()
    local pPlayer = self:GetOwner()
	if ( ToBaseEntity( pPlayer ) == NULL ) then
		return;
	end

	local vForward 		= Vector()
	local vRight 		= Vector()
	local vUp  			= Vector()
	local angle 		= QAngle()
	local vecEye 		= pPlayer:EyePosition();
	pPlayer:EyeVectors( vForward, vRight, vUp );

    local fRange = 62

    local startPos = pPlayer:Weapon_ShootPosition()
    local endPos = startPos + pPlayer:GetAutoaimVector( AUTOAIM_5DEGREES ) * fRange

	self:SendWeaponAnim( ACT.VM_SWINGMISS );
	ToHL2MPPlayer(pPlayer):DoAnimationEvent( PlayerAnimEvent.ATTACK_PRIMARY );

	tr = trace_t()
	MASK_SHOT = _E.MASK.SHOT
    UTIL.TraceLine(startPos, endPos, MASK_SHOT, pPlayer, 0, tr)
	
    local bDidHit = tr:DidHit()
    local hitEnt = tr.m_pEnt

    self.m_flNextPrimaryAttack = gpGlobals.curtime() + 0.25
    self.m_flNextSecondaryAttack = self.m_flNextPrimaryAttack

	if bDidHit then
		if hitEnt then
			self:WeaponSound( WeaponSound.SPECIAL3 )
			self:SendWeaponAnim( ACT.VM_SWINGHIT );
		end

		local vecSrc		= pPlayer:Weapon_ShootPosition();
		local vecAiming		= pPlayer:GetAutoaimVector( AUTOAIM_5DEGREES );

		local info = { m_iShots = 1, m_vecSrc = vecSrc, m_vecDirShooting = vecAiming, m_vecSpread = vec3_origin, m_flDistance = MAX_TRACE_LENGTH, m_iAmmoType = 1 };
		info.m_pAttacker = pPlayer;

		ToHL2MPPlayer( pPlayer ):FireBullets( info );

		local angles = pPlayer:GetLocalAngles();

		angles.x = angles.x + random.RandomInt( 0 );
		angles.y = angles.y + random.RandomInt( 0 );
		angles.z = 0;

if not _CLIENT then
		pPlayer:SnapEyeAngles( angles );
end
	else
		self:WeaponSound( WeaponSound.SINGLE_NPC )
	end

    pPlayer:ViewPunch(QAngle(0, math.random(0,0), 0))

    self.NextIdle = self.m_flNextPrimaryAttack - gpGlobals.curtime()
end

function SWEP:PrimaryAttack()
	local pPlayer = self:GetOwner();

	if ( ToBaseEntity( pPlayer ) == NULL ) then
		return;
	end

    if self.ADS then
        self:SendWeaponAnim( ACT.VM_PRIMARYATTACK_SPECIAL );
    else
        self:SendWeaponAnim( ACT.VM_PRIMARYATTACK );
    end

	if ( self.m_iClip1 <= 0 ) then
		if ( not self.m_bFireOnEmpty ) then
			self:Reload();
		else
			self:WeaponSound( WeaponSound.EMPTY );
			self.m_flNextPrimaryAttack = 0.15;
		end

		return;
	end

	self:WeaponSound( WeaponSound.SINGLE );
	pPlayer:DoMuzzleFlash();
	 
	ToHL2MPPlayer(pPlayer):DoAnimationEvent( PlayerAnimEvent.ATTACK_PRIMARY );

	self.m_flNextPrimaryAttack = gpGlobals.curtime() + 0.10;

	self.m_iClip1 = self.m_iClip1 - 1;

	local vecSrc		= pPlayer:Weapon_ShootPosition();
	local vecAiming		= pPlayer:GetAutoaimVector( AUTOAIM_5DEGREES );

	local info = { m_iShots = 1, m_vecSrc = vecSrc, m_vecDirShooting = vecAiming, m_vecSpread = vec3_origin, m_flDistance = MAX_TRACE_LENGTH, m_iAmmoType = self.m_iPrimaryAmmoType };
	info.m_pAttacker = pPlayer;

	ToHL2MPPlayer( pPlayer ):FireBullets( info );

	local angles = pPlayer:GetLocalAngles();

	angles.x = angles.x + random.RandomInt( 0 );
	angles.y = angles.y + random.RandomInt( 0 );
	angles.z = 0;

if not _CLIENT then
	pPlayer:SnapEyeAngles( angles );
end

	pPlayer:ViewPunch( QAngle( -0.7, random.RandomFloat( 0, 0 ), -0.5 ) );

	if ( self.m_iClip1 == 0 and pPlayer:GetAmmoCount( self.m_iPrimaryAmmoType ) <= 0 ) then
		pPlayer:SetSuitUpdate( "!HEV_AMO0", 0, 0 );
	end
end

function SWEP:SecondaryAttack()
	local pPlayer = self:GetOwner();

	if ( ToBaseEntity( pPlayer ) == NULL ) then
		return;
	end

	    self.ADS = not self.ADS;

    if self.ADS then
        self:ToggleIronsights();
        self:WeaponSound( WeaponSound.SPECIAL1 );
    else
        self:ToggleIronsights();
        self:WeaponSound( WeaponSound.SPECIAL2 );
   end

    self.m_flNextSecondaryAttack = gpGlobals.curtime() + 0.25;
end

function SWEP:Reload()
	if ( self:IsIronsighted() ) then
		self:ToggleIronsights();
	end

	local fRet = self:DefaultReload( self:GetMaxClip1(), self:GetMaxClip2(), 182 );
	if ( fRet ) then
		ToHL2MPPlayer(self:GetOwner()):DoAnimationEvent( PlayerAnimEvent.RELOAD );
	end
	return fRet;
end

function SWEP:Think()
end

function SWEP:CanHolster()
end

function SWEP:Deploy()
    self.NextIdle = gpGlobals.curtime()
end

function SWEP:GetDrawActivity()
	return ACT.VM_DRAW;
end

function SWEP:Holster( pSwitchingTo )
end

function SWEP:ItemPostFrame()
end

function SWEP:ItemBusyFrame()
end

function SWEP:DoImpactEffect()
end

local ConCommand = ConCommand

if SERVER then
    concommand.Create("melee_mw", function(pPlayer, pCmd, ArgS)
        if not IsValid(pPlayer) then return end
        local wep = pPlayer:GetActiveWeapon()
        if IsValid(wep) and wep.Melee then
            wep:Melee()
        end
    end)
end