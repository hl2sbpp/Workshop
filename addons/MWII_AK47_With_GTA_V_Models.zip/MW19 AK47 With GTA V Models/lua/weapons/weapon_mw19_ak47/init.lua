-- init.lua

includeC( "shared.lua" )

function SWEP:CapabilitiesGet()
end