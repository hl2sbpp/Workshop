player_manager.AddValidHands( "TVCamera", "models/schmutz/tvorcameraman_hands.mdl", 0, "10000000", true)
player_manager.AddValidHands( "Cameraman schmutz edition", "models/schmutz/tvorcameraman_hands.mdl", 0, "10000000", true)
player_manager.AddValidHands( "TrueTVman", "models/schmutz/tvorcameraman_hands.mdl", 11, "10000000")
player_manager.AddValidHands( "TVorCameraman", "models/schmutz/tvorcameraman_hands.mdl", 0, "10000000")