list.Set( "PlayerOptionsModel", "Karen", "models/player/smg4_karenstoreclerk_pm.mdl" )
player_manager.AddValidModel( "Karen", "models/player/smg4_karenstoreclerk_pm.mdl" )