--========== Copyright (C) 2025, Team HL2SB++, All rights reserved. ===========--
--
-- Purpose: Initialize the base scripted weapon.
--
--===========================================================================--

includeC("shared.lua")

function SWEP:DrawLargeWeaponBox(bSelected, xpos, ypos, boxWide, boxTall, selectedColor, alpha, number) end

function SWEP:DrawModel(flags) end

function SWEP:MuzzleFlash(pos1, angles, type, firstPerson) end
