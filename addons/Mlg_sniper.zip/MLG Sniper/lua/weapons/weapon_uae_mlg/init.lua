--========== Copyright (C) 2025, Team HL2SB++, All rights reserved. ===========--
--
-- Purpose: Initialize the base scripted weapon.
--
--===========================================================================--

includeC("shared.lua")

function SWEP:CapabilitiesGet() end
