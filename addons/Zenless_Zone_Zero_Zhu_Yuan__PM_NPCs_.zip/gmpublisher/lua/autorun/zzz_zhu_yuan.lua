player_manager.AddValidModel( "Zenless Zone Zero Zhu Yuan", "models/Zhu_Yuan/ZZZ/rstar/Zhu_Yuan/Zhu_Yuan.mdl" );
player_manager.AddValidHands( "Zenless Zone Zero Zhu Yuan", "models/Zhu_Yuan/ZZZ/rstar/Zhu_Yuan/arms/Zhu_Yuan_arms.mdl", 0, "00000000" )

local Category = "R. Star's Models"


local NPC =
{
	Name = "Zenless Zone Zero Zhu Yuan (Friendly)",
	Class = "npc_citizen",
	Health = "100",
	KeyValues = { citizentype = 4 },
	Model = "models/Zhu_Yuan/ZZZ/rstar/Zhu_Yuan/Zhu_Yuan_npc.mdl",
	Category = Category
}

list.Set( "NPC", "ZZZ_Zhu_Yuan_friendly", NPC )



local NPC =
{
	Name = "Zenless Zone Zero Zhu Yuan (Enemy)",
	Class = "npc_combine_s",
	Health = "100",
	Numgrenades = "4",
	Model = "models/Zhu_Yuan/ZZZ/rstar/Zhu_Yuan/Zhu_Yuan_npc.mdl",
	Weapons = { "weapon_pistol" },
	Category = Category
}

list.Set( "NPC", "ZZZ_Zhu_Yuan_enemy", NPC )